<?php
	
	use SilverStripe\ORM\DataObject;
	use SilverStripe\Forms\TextField;
	use SilverStripe\Assets\Image;
	use SilverStripe\Assets\File;
	use SilverStripe\AssetAdmin\Forms\UploadField;
	use SilverStripe\Forms\DropdownField;

	class ModeratedData extends DataObject
	{
    	private static $db = [
			'Title' => 'Varchar',
			'ImageStatus' => 'Varchar'
		];
		
		private static $has_one = [
        	'ReserveAreas' => ReserveArea::class,
        	'ReserveImage' => Image::class
		];
		private static $owns = [
	        'ReserveAreas',
	        'ReserveImage'
		];

		private static $summary_fields = [
	        'Title' => 'Image name',
	        'ImageStatus' => 'Status' 
		];

		
		
		public function getCMSFields()
	    {
	        $fields = parent::getCMSFields();
	        $fields->addFieldToTab('Root.Main', TextField::create('Title'), 'Content' );

	        $StatusData = array(
	        	'Moderated' => 'Select',
	        	'Not Approved' => 'Not Approved',
	        	'Approved' => 'Approved'
	        );
	        $fields->addFieldToTab('Root.Main', DropdownField::create('ImageStatus', 'Image Status', $StatusData ) );
	
	        return $fields;
	    }
        

	}

