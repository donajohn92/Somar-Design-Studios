<?php
use SilverStripe\Admin\ModelAdmin;
class ReserveAreaAdmin extends ModelAdmin {
	private static $managed_models = [
		'ReserveArea'
	];
	private static $url_segment = 'reservearea';
	private static $menu_title = 'Reserve Areas';
	public function getEditForm($id = null, $fields = null) {
		$form=parent::getEditForm($id, $fields);
		if($this->modelClass=='ReserveArea' && $gridField=$form->Fields()->dataFieldByName($this->sanitiseClassName($this->modelClass))) {
			if($gridField instanceof GridField) {
				$gridField->getConfig()->addComponent(new GridFieldSortableRows('SortOrder'));
			}
		}
		return $form;
	}
}