<?php
	use SilverStripe\ORM\DataObject;
	use SilverStripe\Forms\TextField;
	use SilverStripe\Forms\FieldList;
	/*use SilverStripe\Forms\DropdownField;
	use SilverStripe\Forms\TextareaField;*/
	use SilverStripe\Forms\GridField\GridField;
	use SilverStripe\Forms\GridField\GridFieldConfig_RecordEditor;
	use SilverStripe\Versioned\Versioned;	
	use SilverStripe\Forms\TabSet;

	class ReserveArea extends DataObject 
	
	{
    	private static $db = [
			'Title' => 'Varchar',
			'ObjectID' => 'Varchar',
			'Description' => 'Varchar'
		];
		
		private static $default_sort = 'ID ASC';	
	    private static $versioned_gridfield_extensions = true;
		
	    private static $has_many = [
	    	'ModeratedDatas' => ModeratedData::class
		];
		private static $owns = [
	        'ModeratedDatas'
		];

		private static $summary_fields = [
	        'Title' => 'Area Name',
	        'ModerationDetails' => 'Moderated Images'
		];

		function getModerationDetails(){
			$ID = $this->ID;
			$ListData = ModeratedData::get()->Filter( array(
				'ReserveAreasID' => $ID
			) );
			$count = 0;
			foreach( $ListData as $k => $v ){
				$status = $v->ImageStatus;
				if( $status != 'Approved' && $status != 'Not Approved' ){
					$count++;
				}
			}
			return $count;
		}

		public function getCMSFields()
	    {

	        $fields = FieldList::create(TabSet::create('Root'));
			$fields->addFieldsToTab(
				'Root.main',
				[
					// fields
					TextField::create('Title'),
		            TextField::create('ObjectID'),
		            TextField::create('Description')
				]
			);			

	        $fields->addFieldToTab('Root.ModeratedDatas', GridField::create(
	        	'ModeratedDatas',
				'Moderated Data',
				$this->owner->ModeratedDatas(),
				GridFieldConfig_RecordEditor::create()
			));
		
	        $this->extend('updateCMSFields', $fields);

	        return $fields;
	    }
	}
	
	
	
	
	
	
	
	
	