<?php
use SilverStripe\Assets\Image;
use SilverStripe\Assets\File;
use SilverStripe\Control\HTTPRequest;
use SilverStripe\Core\Injector\Injector;

class ReserveAreaDetailPageController extends PageController
{

	private static $uploaded = 0;
	
	function init(){

		parent::init();

		$request = Injector::inst()->get(HTTPRequest::class);
		$session = $request->getSession();

		$action = @$_REQUEST['action'];
		if( $action == 'uploadImages' ){
			$reserveImage = $_FILES['reserveImage'];
			
			$ModeratedData = new ModeratedData();
			if( !empty($reserveImage['tmp_name']['0']) ){
				$content = file_get_contents($reserveImage['tmp_name']['0']);
				$file = new Image();
				$file->setFromString($content, $reserveImage['name']['0']);
				$file->write();

				$ModeratedData->ReserveAreasID = $_REQUEST['reserveID'];
				$ModeratedData->Title = $reserveImage['name']['0'];
				$ModeratedData->ReserveImageID = $file->ID;

				$ModeratedData->write();
				
				$session->set('ImageUploaded', true);
			}
		}
	}

	function checkImageUpload(){
		$request = Injector::inst()->get(HTTPRequest::class);
		$session = $request->getSession();
		$data = $session->get('ImageUploaded');
		
		return $data;
	}

	function removeSuccessMessage(){
		$request = Injector::inst()->get(HTTPRequest::class);
		$session = $request->getSession();
		$session->clear('ImageUploaded');
	}

	function getReserveAreaData(){
		$reserveId = $this->getRequest()->getVar('id');
		//echo $reserveId; exit;
		$List = ReserveArea::get()->byID( $reserveId );

		return $List;
	}

	function getAreaImageRandom(){		
		return 'area1.jpg';		
	}

	function getReserveID(){
		return $this->getRequest()->getVar('id');
	}

	function getModeratedDatas(){
		// return only approved image data
		$DataID = $this->getRequest()->getVar('id');
		$Data = ModeratedData::get()->Filter( array(
			'ImageStatus' => 'Approved',
			'ReserveAreasID' => $DataID
		));

		return $Data;
	}

}

