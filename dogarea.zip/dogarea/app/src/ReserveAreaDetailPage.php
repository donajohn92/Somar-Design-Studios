<?php

//use Page;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldConfig_RecordEditor;
use SilverStripe\Versioned\Versioned;
use SilverStripe\CMS\Model\SiteTree;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\HTMLEditor\HtmlEditorField;
use SilverStripe\Forms\TextAreaField;
use SilverStripe\Assets\Image;
use SilverStripe\Assets\File;
use SilverStripe\AssetAdmin\Forms\UploadField;

class ReserveAreaDetailPage extends Page
{
	private static $db = [
		//'Description' => 'HTMLText'
	];

    
	private static $has_many = [
    	//'AboutUsDatas' => AboutUsData::class
	];
	private static $owns = [
        //'AboutUsDatas'
	];

	public function getCMSFields() 
	{
		$fields = parent::getCMSFields();
		
		/*$fields->addFieldToTab('Root.Details', HtmlEditorField::create('Description') );
		$fields->addFieldToTab('Root.Details', GridField::create(
        	'AboutUsDatas',
			'Data',
			$this->owner->AboutUsDatas(),
			GridFieldConfig_RecordEditor::create()
		));*/

	    return $fields;
	}
}













