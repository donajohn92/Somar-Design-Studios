<?php

class ReserveAreaPageController extends PageController
{
	
	function getReserveAreaList(){
		$List = ReserveArea::get()->limit(20);
		return $List;
	}

	function getAreaImage( $PositionCount ){
		//echo $PositionCount; exit;
		if( $PositionCount % 2 == 0 ){
			return 'area2.jpg';
		}else if( $PositionCount % 3 == 0 ){
			return 'area3.jpg';
		}else{
			return 'area1.jpg';
		}
	}

}

